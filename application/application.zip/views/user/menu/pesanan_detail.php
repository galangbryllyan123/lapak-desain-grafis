    <section class="site-section">
      <div class="container">
        <div class="row">

          <div class="col-md-12">
            <div class="col-md-12 col-lg-12">
              <center><img src="<?=base_url()?>images/img_6.jpg" style="width: 400px; height: 300px;">
              <h2 class="font-size-regular"><a href="#">Warehousing Your Packages</a></h2>
              <div class="meta mb-4">Theresa Winston <span class="mx-2">&bullet;</span> Jan 18, 2019<span class="mx-2">&bullet;</span> <a href="#">News</a></div></center>
              

               

            </div>
             
            
          </div> 

          

        </div>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h2 class="h4 text-black mb-5">Form Pembayaran</h2> 
            <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">No Rekening Toko</label> 
                <input type="Text" id="email" class="form-control" value="784513542" disabled="">
              </div>
            </div>

            <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">Nama Rekening Toko</label> 
                <input type="Text" id="email" class="form-control" value="Kicap Karan" disabled="">
              </div>
            </div>

            <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">Harga Desain</label> 
                <input type="Text" id="email" class="form-control" value="Rp. 100.000 / 100 pcs" disabled="">
              </div>
            </div>

            <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">Harga Cetak</label> 
                <input type="Text" id="email" class="form-control" value="Rp. 5.000 / 1 pcs" disabled="">
              </div>
            </div>

            <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">Kode Unik</label> 
                <input type="Text" id="email" class="form-control" value="Rp. 71" disabled="">
              </div>
            </div>

             <div class="row form-group">
              
              <div class="col-md-12">
                <label class="text-black" for="email">Total Harga</label> 
                <input type="Text" id="email" class="form-control" value="Rp. 150.071" disabled="">
              </div>
            </div>

              

  
          </div>


          <div class="col-md-5">

            <div class="row form-group">
              <div class="col-md-7 mb-3 mb-md-0">
                <label class="text-black" for="fname">Upload Bukti Pembayaran</label>
                <input type="file" id="fname" class="form-control">
              </div>
              <div class="col-md-5">
                <label class="text-black" for="lname"></label>
                <input type="submit" value="Upload Bukti Pembayaran" class="btn btn-primary btn-md text-white">
              </div>
            </div>
            
             <br><br>

            <div class="p-4 mb-3 bg-white">
              <h2 class="h4 text-black ">Komentar</h2> 
              <p class="mb-0 font-weight-bold">Nama 1</p>
              <p class="mb-4">Komentar Nama 1</p>
              <hr>
              
              <p class="mb-0 font-weight-bold">Nama 2</p>
              <p class="mb-4">Komentar Nama 2</p>
              <hr>
              
              <p class="mb-0 font-weight-bold">Nama 3</p>
              <p class="mb-4">Komentar Nama 3</p>
              <hr>
              
              <p class="mb-0 font-weight-bold">Nama 4</p>
              <p class="mb-4">Komentar Nama 4</p>
              <hr>

              <p class="mb-0 font-weight-bold">Nama 5</p>
              <p class="mb-4">Komentar Nama 5</p>
              <hr>
              <div class="col-11">
                <div class="custom-pagination text-center">
                  <span>1</span>
                  <a href="#">2</a>
                  <a href="#">3</a>
                  <span class="more-page">...</span>
                  <a href="#">10</a>
                </div>
              </div>
            </div>
            

            
            

          </div>
        </div>
      </div>
    </section>

