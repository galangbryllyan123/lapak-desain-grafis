		<footer class="footer">
			<ul class="list-inline">
				<li>2020 © <i>Desain</i>-<b>Grafis</b>.</li>
				<li><a href="#">Privacy</a></li>
				<li><a href="#">Terms</a></li>
				<li><a href="#">Help</a></li>
			</ul>
		</footer>